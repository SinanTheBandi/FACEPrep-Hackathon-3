import http.server
import socketserver
import webbrowser
import os

PORT = 8000  # You can change this to any available port
directory = "."  # The main directory containing the index.html file and the "restaurant" and "Knight" folders

Handler = http.server.SimpleHTTPRequestHandler

# Change the directory to the main directory
os.chdir(directory)

# Open the default web browser to localhost
webbrowser.open('http://localhost:' + str(PORT))

# Start the server
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print("Serving at port", PORT)
    httpd.serve_forever()
