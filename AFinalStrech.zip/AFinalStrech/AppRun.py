import webbrowser
import os

html_file = "index.html"

html_path = os.path.abspath(html_file)

webbrowser.open('file://' + html_path)